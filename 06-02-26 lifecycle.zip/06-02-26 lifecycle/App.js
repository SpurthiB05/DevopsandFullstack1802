import React, { Component } from "react";
import StudentProfile from "./StudentProfile";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showProfile: true,
    };
  }

  toggleProfile = () => {
    this.setState({ showProfile: !this.state.showProfile });
  };

  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <h1>React Lifecycle Demo</h1>

        <button onClick={this.toggleProfile}>
          Toggle Student Profile
        </button>

        {this.state.showProfile && <StudentProfile />}
      </div>
    );
  }
}

export default App;
