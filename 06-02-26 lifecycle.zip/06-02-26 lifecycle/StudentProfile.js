import React, { Component } from "react";

class StudentProfile extends Component {
  constructor(props) {
    super(props);
    console.log("Constructor called");

    this.state = {
      students: []
    };
  }

  componentDidMount() {
    console.log("Component Mounted");

    // Mock student data
    const studentData = [
      { id: 1, name: "Billa Spurthi", email: "spurthi@gmail.com", city: "Hyderabad" },
      { id: 2, name: "Bharath", email: "bharath@gmail.com", city: "Bangalore" },
      { id: 3, name: "Seety", email: "seety@gmail.com", city: "Chennai" },
      { id: 4, name: "Bobby", email: "bobby@gmail.com", city: "Delhi" },
      { id: 5, name: "Bobsee", email: "bobsee@gmail.com", city: "Mumbai" },
      { id: 6, name: "Bobseeta", email: "bobseeta@gmail.com", city: "Pune" }
    ];

    this.setState({ students: studentData });
  }

  componentDidUpdate() {
    console.log("Component Updated");
  }

  componentWillUnmount() {
    console.log("Component Will Unmount");
  }

  render() {
    return (
      <div style={styles.container}>
        <h2 style={styles.heading}>Student Profiles</h2>

        <div style={styles.cardContainer}>
          {this.state.students.map((student) => (
            <div key={student.id} style={styles.card}>
              <h3>{student.name}</h3>
              <p><strong>Email:</strong> {student.email}</p>
              <p><strong>City:</strong> {student.city}</p>
            </div>
          ))}
        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    padding: "30px",
    minHeight: "100vh",
    background: "linear-gradient(to right, #667eea, #764ba2)",
  },
  heading: {
    textAlign: "center",
    color: "white",
    fontSize: "32px",
    marginBottom: "30px",
    letterSpacing: "1px"
  },
  cardContainer: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: "25px"
  },
  card: {
    padding: "20px",
    borderRadius: "15px",
    width: "250px",
    color: "white",
    background: "linear-gradient(135deg, #ff758c, #ff7eb3)",
    boxShadow: "0 8px 20px rgba(0,0,0,0.3)",
    transition: "transform 0.3s ease",
    cursor: "pointer"
  }
};

export default StudentProfile;
