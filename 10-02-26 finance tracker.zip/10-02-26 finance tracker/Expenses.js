function Expenses() {
  return <h2>Expenses Page</h2>;
}

export default Expenses;
