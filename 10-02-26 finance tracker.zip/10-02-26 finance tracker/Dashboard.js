import LogoutButton from "../components/LogoutButton";

function Dashboard() {
  return (
    <div className="page">
      <h2>Dashboard</h2>
      <p>Welcome to your finance overview.</p>
      <LogoutButton />
    </div>
  );
}

export default Dashboard;
