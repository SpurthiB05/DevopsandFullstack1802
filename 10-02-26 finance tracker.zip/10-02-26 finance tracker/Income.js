function Income() {
  return <h2>Income Page</h2>;
}

export default Income;
