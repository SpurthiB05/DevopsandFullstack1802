import React from "react";
import CartItem from "./CartItem";

function Cart() {
  const items = [
    { id: 1, name: "Awesome Item", price: 20, color: "#FFE4E1" },
    { id: 2, name: "Cool Gadget", price: 35, color: "#E0FFFF" },
    { id: 3, name: "Smart Watch", price: 50, color: "#F0FFF0" },
    { id: 4, name: "Wireless Earbuds", price: 45, color: "#FFFACD" },
    { id: 5, name: "Power Bank", price: 25, color: "#E6E6FA" },
  ];

  return (
    <div style={{ textAlign: "center", marginTop: "40px" }}>
      <h1 style={{ color: "#333" }}>🛒 Shopping Cart</h1>

      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
        {items.map((item) => (
          <CartItem key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}

export default Cart;
