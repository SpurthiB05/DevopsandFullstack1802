import React, { useState } from "react";

function CartItem({ item }) {
  const [quantity, setQuantity] = useState(1);

  return (
    <div
      style={{
        backgroundColor: item.color,
        borderRadius: "12px",
        padding: "20px",
        width: "260px",
        margin: "15px",
        boxShadow: "0 6px 12px rgba(0,0,0,0.15)",
      }}
    >
      <h2 style={{ color: "#444" }}>Item Details</h2>
      <p><strong>Product:</strong> {item.name}</p>
      <p><strong>Price:</strong> ${item.price}</p>
      <p><strong>Quantity:</strong> {quantity}</p>

      <div style={{ marginTop: "10px" }}>
        <button
          onClick={() => setQuantity(quantity + 1)}
          style={buttonStyle}
        >
          +
        </button>

        <button
          onClick={() => quantity > 1 && setQuantity(quantity - 1)}
          style={{ ...buttonStyle, margin: "0 8px" }}
        >
          -
        </button>

        <button
          onClick={() => setQuantity(1)}
          style={{ ...buttonStyle, backgroundColor: "#ff6b6b" }}
        >
          Reset
        </button>
      </div>
    </div>
  );
}

const buttonStyle = {
  padding: "6px 12px",
  fontSize: "16px",
  borderRadius: "6px",
  border: "none",
  cursor: "pointer",
  backgroundColor: "#4CAF50",
  color: "white",
};

export default CartItem;
